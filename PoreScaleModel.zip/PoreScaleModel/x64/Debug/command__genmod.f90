        !COMPILER-GENERATED INTERFACE MODULE: Wed Apr 24 23:19:45 2024
        ! This source file is for reference only and may not completely
        ! represent the generated interface used by the compiler.
        MODULE COMMAND__genmod
          INTERFACE 
            SUBROUTINE COMMAND(TERM,UNIT)
              CHARACTER(*) :: TERM
              INTEGER(KIND=4) :: UNIT
            END SUBROUTINE COMMAND
          END INTERFACE 
        END MODULE COMMAND__genmod
